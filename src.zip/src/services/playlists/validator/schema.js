import Joi from 'joi';

const PostPlaylistPayloadSchema = Joi.object({
  name: Joi.string().required(),
});

const PostPlaylistSongPayloadSchema = Joi.object({
  // playlistId: Joi.string().required(),
  songId: Joi.string().required(),
});

export {
  PostPlaylistPayloadSchema,
  PostPlaylistSongPayloadSchema,
};